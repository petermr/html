An HTML5 parser.

Please see http://about.validator.nu/htmlparser/

-- Henri Sivonen (hsivonen@iki.fi).
